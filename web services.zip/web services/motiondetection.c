/**
 * @file ax_event_subscription_example.c
 *
 * @brief This example illustrates how to setup an subscription to the
 * manual trigger event.
 *
 * Error handling has been omitted for the sake of brevity.
 */

#include <glib.h>
#include <glib-object.h>
#include <axsdk/axevent.h>
#include <syslog.h>

static void
subscription_callback(guint subscription,
    AXEvent *event, guint *token);

static guint
subscribe_to_motion_detection(AXEventHandler *event_handler,
     guint *token);

static void
subscription_callback(guint subscription,
    AXEvent *event, guint *token)
{
  const AXEventKeyValueSet *key_value_set;
  
  gboolean state;

  /* The subscription id is not used in this example. */
  (void)subscription;

  /* Extract the AXEventKeyValueSet from the event. */
  key_value_set = ax_event_get_key_value_set(event);



  /* Get the state of the manual trigger port . */
  ax_event_key_value_set_get_boolean(key_value_set,
        "active", NULL, &state, NULL);
static int i=0;
  /* Print a helpfull message. */
  if (state) {

    syslog(LOG_INFO, "Motion_Detection started i= %d", i);
i++;
   // g_message("Motion detection triggered I am a gmessage");
  } else {
    syslog(LOG_INFO, "Motion_Detection ended i= %d",i);
i++;
   // g_message("Motion detection is not triggered I am a gmessage");

  }

  g_message("And here's the token: %d", *token);
}

static guint
subscribe_to_motion_detection(AXEventHandler *event_handler,
     guint *token)
{
  AXEventKeyValueSet *key_value_set;
  guint subscription;

  key_value_set = ax_event_key_value_set_new();

  /* Initialize an AXEventKeyValueSet that matches the manual trigger event.
   * 
   * tns1:topic0=Device
   * tnsaxis:topic1=IO
   * tnsaxis:topic2=VirtualPort
   * port=&port  <-- Subscribe to "port" input argument
   * state=*     <-- Subscribe to all states
   */
  
/*ax_event_key_value_set_add_key_values(key_value_set,
        NULL,
        "topic0", "tns1", "Device", AX_VALUE_TYPE_STRING,
        "topic1", "tnsaxis", "IO", AX_VALUE_TYPE_STRING,
        "topic2", "tnsaxis", "VirtualPort", AX_VALUE_TYPE_STRING,
        "port", NULL, &port, AX_VALUE_TYPE_INT,
        "state", NULL, NULL, AX_VALUE_TYPE_BOOL,
        NULL); */


  ax_event_key_value_set_add_key_values(key_value_set,	
	  NULL,
	  "topic0","tns1","RuleEngine",AX_VALUE_TYPE_STRING,
	  "topic1","tnsaxis","VMD3",AX_VALUE_TYPE_STRING,
	  "active", NULL, NULL,AX_VALUE_TYPE_BOOL,
	   NULL);



  /* Time to setup the subscription. Use the "token" input argument as
   * input data to the callback function "subscription callback"
   */
  ax_event_handler_subscribe(event_handler, key_value_set,
        &subscription, (AXSubscriptionCallback)subscription_callback, token,
        NULL);

  /* The key/value set is no longer needed */
  ax_event_key_value_set_free(key_value_set);

  return subscription;
}

int main(void)
{
  GMainLoop *main_loop;
  AXEventHandler *event_handler;
  guint subscription;
  guint token = 1234;

  main_loop = g_main_loop_new(NULL, FALSE);

  event_handler = ax_event_handler_new();

  subscription = subscribe_to_motion_detection(event_handler,
     &token); 

  g_main_loop_run(main_loop);

  ax_event_handler_unsubscribe(event_handler, subscription, NULL);

  ax_event_handler_free(event_handler);

  return 0;
}

