package test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.DefaultProxyRoutePlanner;
import org.junit.Test;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import com.horn.Constants;

public class TestMotionLog {
	
	
	//@Test
    public void testConnection() {
		String plainCreds = "root:pass";		
		String base64Creds = Base64.getEncoder().encodeToString(plainCreds.getBytes());
		
		HttpHeaders headers = new HttpHeaders();
		headers.add("Authorization", "Digest " + base64Creds);
		
		RestTemplate restTemplate = new RestTemplate();
		String url = "http://192.168.20.246/axis-cgi/admin/systemlog.cgi";

		HttpEntity<String> request = new HttpEntity<String>(headers);
		ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, request, String.class);
		System.out.println(response.getBody());
    }
	
	//@Test
	public void testConnectionWithProxy(){
//		HttpHost proxy = new HttpHost("proxy.com", 80, "http");
//		DefaultProxyRoutePlanner routePlanner = new DefaultProxyRoutePlanner(proxy);
//		CloseableHttpClient httpclient = HttpClients.custom()
//		                    .setRoutePlanner(routePlanner)
//		                    .build();
	}
	//@Test
	public void testConnectionWithProxyRest(){
		RestTemplate restTemplate = new RestTemplate();
		HttpHost httpHost = new HttpHost(
		        System.getProperty("http.proxyHost"),
		        Integer.parseInt(System.getProperty("http.proxyPort"))
		);
		DefaultProxyRoutePlanner defaultProxyRoutePlanner = new DefaultProxyRoutePlanner(httpHost);
		HttpClient httpClient = HttpClients.custom().setRoutePlanner(defaultProxyRoutePlanner).build();
		restTemplate.setRequestFactory(new HttpComponentsClientHttpRequestFactory(httpClient));
	}
	
	@Test
	public void testConnectionWithDigest() throws ClientProtocolException, IOException{
		CredentialsProvider credsProvider = new BasicCredentialsProvider();
        credsProvider.setCredentials(
                new AuthScope(AuthScope.ANY_HOST, AuthScope.ANY_PORT),
                new UsernamePasswordCredentials(Constants.AXIS_USER_NAME, Constants.AXIS_PASSWORD));
        CloseableHttpClient httpClient = HttpClients.custom()
                .setDefaultCredentialsProvider(credsProvider)
                .build();
        
        HttpGet request = new HttpGet(Constants.AXIS_CAMERA_URL);

		HttpResponse response = httpClient.execute(request);
		
		
		System.out.println("Response Code : "
                + response.getStatusLine().getStatusCode());

		BufferedReader rd = new BufferedReader(
			new InputStreamReader(response.getEntity().getContent()));
		
		StringBuffer result = new StringBuffer();
		List<String> logResult = new ArrayList <String> ();
		String line = "";
		int i=1;
		while ((line = rd.readLine()) != null) {
			result.append(line);
			logResult.add(line);
			System.out.println(line);
			i++;
		}
		
		//System.out.println(result.toString());
	}
	
}
