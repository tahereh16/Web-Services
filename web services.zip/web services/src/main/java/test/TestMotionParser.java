package test;

import java.util.ArrayList;
import java.util.List;

import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.horn.domain.MotionEvent;
import com.horn.motion.MotionParser;

public class TestMotionParser {
	private static List<String> dummyLog2;
	
	private static final Logger logger = LoggerFactory.getLogger(TestMotionParser.class);


	
	@Test
	public void testMotionParserLog(){
		MotionParser motionParser = new MotionParser(DummyLog.getDummyLog());
		List<MotionEvent> resuultEvent = motionParser.getMotionEventsInRangeOf("10", "23") ;
		
	}
	
	@Test
	public void testMotionParserLog2(){
		MotionParser motionParser = new MotionParser(dummyLog2);
		//motionParser.getMotionEventsFromLog();
		
	}
}
