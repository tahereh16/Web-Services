package com.horn;

// TODO: Auto-generated Javadoc
/**
 * The Class Constants.
 */
public class Constants {
	public static final String AXIS_CAMERA_URL = "http://192.168.20.249/axis-cgi/admin/systemlog.cgi";
	public static final String AXIS_USER_NAME = "root";
	public static final String AXIS_PASSWORD = "pass";
	
	public static final String SEARCH_QUERY_MOTION_START = "MOTION_DETECTION STARTED";
	public static final String SEARCH_QUERY_MOTION_FINISH= "MOTION_DETECTION ENDED";

}
