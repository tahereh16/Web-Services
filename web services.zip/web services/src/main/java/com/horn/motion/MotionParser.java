package com.horn.motion;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.horn.Constants;
import com.horn.domain.MotionEvent;


public class MotionParser {
	private static final Logger logger = LoggerFactory.getLogger(MotionParser.class);
	List<LocalTime> startTimeList;
	List<LocalTime> endTimeList; 
	List<MotionEvent> motionEventList = null;

	
	private List<String> log;
	
	public MotionParser (List<String> log){
		this.log = log;
		startTimeList = new ArrayList<LocalTime>();
		endTimeList = new ArrayList<LocalTime>();
		motionEventList = new ArrayList<MotionEvent>();;

	}
	
	
	private void generateMotionEventsFromLog(){
		fillStartEndTimeLists();
		if(startTimeList.size()>0 && endTimeList.size()>0 ){
			for(int i=0; i <  getMotionSize(); i++){
				motionEventList.add(new MotionEvent(startTimeList.get(i),endTimeList.get(i) ));
			}
			logger.debug("Creating Motion events are successfull");

		}else{
			logger.error("Motion Event List can not be generated no motions detected");
		}
	}
	
	public List<MotionEvent> getMotionEventsInRangeOf( String startHour, String endHour){
		
		LocalTime startTime = LocalTime.of(Integer.valueOf(startHour), 0);
		LocalTime endTime = LocalTime.of(Integer.valueOf(endHour), 0);
		generateMotionEventsFromLog();
		List<MotionEvent> selectedMotionEventList = new ArrayList<MotionEvent>();
		
		for(MotionEvent motionEvent: motionEventList){
			if(motionEvent.getStartTime().isAfter(startTime) && motionEvent.getStartTime().isBefore(endTime) ){
				selectedMotionEventList.add(motionEvent);
			}
		}		
		
		return selectedMotionEventList;
	}
	
	private void fillStartEndTimeLists(){

		if(log!=null && log.size() > 0 && startTimeList != null && endTimeList != null){			
			for(String logString : log){
				if(logString.contains(Constants.SEARCH_QUERY_MOTION_START) && isAvailableMotion(logString)){
					startTimeList.add(createLocalTimeFromString(logString));
				}else if(logString.contains(Constants.SEARCH_QUERY_MOTION_FINISH) && isAvailableMotion(logString)){
					endTimeList.add(createLocalTimeFromString(logString));
				}
			}			
			logger.debug("Parsing log file is successfull");
		}else{
			logger.error("Log file is null");
		}
	}
	
	private LocalTime createLocalTimeFromString(String logString){
		String timeString = logString.substring(logString.indexOf('T') + 1, logString.indexOf('T') + 9);
		String nanoString = logString.substring(logString.indexOf('T') + 10, logString.indexOf('T') + 13);

		String[] timeArray = timeString.split(":");

		return LocalTime.of(Integer.parseInt(timeArray[0]), Integer.parseInt(timeArray[1]), Integer.parseInt(timeArray[2]), Integer.parseInt(nanoString));
	}
	
	private boolean isAvailableMotion(String logString){
		Integer motionIndex = Integer.valueOf(logString.substring(logString.indexOf("I=")+3));
		if(motionIndex >=2){
			return true;
		}else {
			return false;
		}
	}
	
	private int getMotionSize(){
		int motionSize = startTimeList.size();
		if(motionSize > endTimeList.size()) {
			motionSize = endTimeList.size();
		}
		return motionSize;
	}
}
