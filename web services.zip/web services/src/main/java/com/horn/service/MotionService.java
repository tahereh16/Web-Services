package com.horn.service;

import java.io.IOException;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.horn.domain.MotionEvent;
import com.horn.motion.MotionParser;

import test.DummyLog;

@Service
public class MotionService {
	
	@Autowired
	MotionLoggerService motionLoggerService;
	
	public List<MotionEvent> getDummyEvents(String startTime, String endTime){
		MotionParser motionParser = new MotionParser(DummyLog.getDummyLog());
		return motionParser.getMotionEventsInRangeOf(startTime, endTime);
	}
	
	public List<MotionEvent> getAllEvents(String startTime, String endTime){
		MotionParser motionParser = null;
		try {
			motionParser = new MotionParser(motionLoggerService.getLogFileFromCamera());
		} catch (IOException e) {
			e.printStackTrace();
		}
		return motionParser.getMotionEventsInRangeOf(startTime,endTime );
	}

}
