package com.horn.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.springframework.stereotype.Service;



@Service
public class MotionLoggerService {
	
	public List<String> getLogFileFromCamera() throws ClientProtocolException, IOException{
		CredentialsProvider credsProvider = new BasicCredentialsProvider();
        credsProvider.setCredentials(
                new AuthScope(AuthScope.ANY_HOST, AuthScope.ANY_PORT),
                new UsernamePasswordCredentials("root", "pass"));
        CloseableHttpClient httpClient = HttpClients.custom()
                .setDefaultCredentialsProvider(credsProvider)
                .build();
        
        String url = "http://192.168.20.249/axis-cgi/admin/systemlog.cgi";
        HttpGet request = new HttpGet(url);

		HttpResponse response;
			response = httpClient.execute(request);
	
		
		
		System.out.println("Response Code : "
                + response.getStatusLine().getStatusCode());

		BufferedReader rd = new BufferedReader(
			new InputStreamReader(response.getEntity().getContent()));
		
		List<String> logResult = new ArrayList <String> ();
		String line = "";
		while ((line = rd.readLine()) != null) {
			logResult.add(line.toUpperCase());
		}
		
		return logResult;
	}
	

}
